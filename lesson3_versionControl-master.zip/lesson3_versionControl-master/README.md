# Project Name:  Lesson 3 Version Control

## Course Title:
LIS 2360:  Web Application Development

## Assignment Date:  
January 30, 2017

## Student Name:  
Meredith McNulty

## Project Description:
Learning how to use Git & GitHub effectively.

## Lessons Learned in the Assignment:
1. What is Git
2. How Git is helpful and how it is used
3. GitHub and its features
