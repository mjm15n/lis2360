## Project Name:  Expense Calculator Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
Feb. 8th 2017

### Student Name:  
Meredith McNulty

### Project Description:
This project provided a brief introduction to JavaScript and allowed students to practice using the language.

### View Project:
https://mjm15n.github.io/lesson4_javascript1/

### Lessons Learned in the Assignment:
1. JavaScript is a scripting language (lightweight & interactive)
2. Interpreted on-the-fly by the client
3. Uses variables, initializes them and dispalys them if needed.
