## Project Name:  Seminole Movie Connection Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
April 13, 2017

### Student Name:  
Meredith McNulty

### Project Description:
In this project, we learned how to use Ajax, JSON, and the IMDb API to access movie data.

### View Project:
https://mjm15n.github.io/lesson8_ajax/

### Lessons Learned in the Assignment:
1. Updating Web Pages with Ajax
2. Basic Syntax, Datatypes, how JSON works
3. How to use APIs
