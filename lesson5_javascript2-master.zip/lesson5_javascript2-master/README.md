## Project Name:  Expense Calculator Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
2.20.17

### Student Name:  
Meredith McNulty

### Project Description:
This assignment provided students with more practice using comparison and arithmetic operators in JavaScript.

### View Project:
https://mjm15n.github.io/lesson5_javascript2/

### Lessons Learned in the Assignment:
1. Comparison Operators
2. if Statements
3. Working with Functions
