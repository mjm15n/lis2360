## Project Name:  Photo Gallery Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
March 5, 1017

### Student Name:  
Meredith McNulty

### Project Description:
This assignment taught how to access elements and their content, add and remove document nodes, and create and close new browser tabs and windows with
an app

### View Project:
https://mjm15n.github.io/lesson6_javascript3/

### Lessons Learned in the Assignment:
1. The Document Object Model
2. Browser Object Model (BOM)
3. Dynamic HyperText Markup Language
