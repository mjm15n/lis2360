## Project Name:  Recipe Display Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
March 22, 2017

### Student Name:  
Meredith McNulty

### Project Description:
This assignment was an introduction to using jQuery, a commonly used library that lets developers implement common JavaScript
tasks with minimal code.

### View Project:
https://mjm15n.github.io/lesson7_jquery/Lesson7_Assignment/index2.html

### Lessons Learned in the Assignment:
1. Selecting elements using jQuery syntax
2. Using built-in jQuery functions
3. Specifying an Event Handler
