## Project Name:  Seminole Weather Channel Application

### Course Title:
LIS 2360:  Web Application Development

### Assignment Date:  
April 13, 2017

### Student Name:  
Meredith McNulty

### Project Description:
This assignment uses an API from APIXU to build a weather web application.

### View Project:
https://mjm15n.github.io/WeatherChannel/

### Lessons Learned in the Assignment:
1. Updating Web Pages with Ajax
2. Basic Syntax, Datatypes, how JSON works
3. How to use APIs